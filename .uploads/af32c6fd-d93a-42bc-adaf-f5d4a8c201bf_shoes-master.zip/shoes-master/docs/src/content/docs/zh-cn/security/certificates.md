---
title: "证书来源"
description: "shoes 证书源配置。"
---

普通 TLS 目标和 QUIC 监听器可以共享命名证书源。使用`certificate_source`代替`cert`和`key`；将它们组合起来是一个错误。仍然支持现有的内联证书、文件路径和命名 PEM。

证书含重复 SCT 扩展或格式错误的外层 DER OCTET STRING 时会被拒绝。
即使客户端仅验证指纹或设置 `verify: false`，此解析要求仍然适用；
它不会启用 CT 日志验证。内置公共根证书已移除 DigiCert Trusted Root G4、
QuoVadis Root CA 1 G3/3 G3、Buypass Class 2/3 Root CA 和 Certigna Root CA。
仅依赖这些根的服务器需要改用不受影响的证书链。

```yaml
- certificate_source: public
  type: files
  cert: /etc/shoes/certs/fullchain.pem
  key: /etc/shoes/certs/privkey.pem

- address: "0.0.0.0:443"
  protocol:
    type: tls
    tls_targets:
      proxy.example.com:
        certificate_source: public
        protocol: {type: trojan, password: change-me}

- address: "0.0.0.0:443"
  transport: quic
  quic_settings:
    certificate_source: public
  protocol: {type: hysteria2, password: change-me}
```

每个源有一个运行时工作线程，而不是每个监听器。文件源使用与配置文件相同的文件系统观察器机制，在最后一个相关事件之后有 250 毫秒的安静期。它们支持原子重命名和符号链接替换。完整的证书链及其匹配的私钥必须在发布前进行验证。单独的文件写入、丢失的文件、格式​​错误的数据、密钥不匹配和无效的有效期都会使最后一个好的对保留在适当的位置。失败的更新每秒重试； 60 秒的内部协调还可恢复错过的事件或不可用的监视。这两个间隔都不是配置设置。错误率是有限的，并且绝不包括私人材料。过期的源会导致新的握手失败，而不是提供替代证书。现有连接将继续不间断。

初始文件源加载（包括旧路径）会拒绝过期或无效的链、格式错误或顺序错误的链以及大于 1 MiB 的 PEM 文件。被拒绝的配置重新加载会使当前监听器继续运行并监视候选者的文件路径，以便修复该对并重试重新加载。激活后，仅身份更改使用实时轮换，而不是完全重新加载。

**升级警告：** 即使没有更改配置，这些检查也适用于现有的 `cert`/`key` 文件路径和文件支持的命名 PEM。以前接受的过期或尚未生效的证书以及顺序错误的捆绑包现在在启动时被拒绝；运行的文件源在到期时停止服务，包括当客户端禁用验证或固定指纹时。更新过期的证书，将捆绑包按叶到发行者的顺序放置，删除链外过期的交叉签名和证书，并在启动 shoes 之前同步系统时钟。子颁发者签名必须使用 TLS 提供程序支持的算法：无 SHA-1，并且 RSA 颁发者密钥必须至少为 2048 位。重新颁发具有不受支持的签名的证书。仅内联对保留其先前的静态行为。

旧版 `cert`/`key` 路径（包括通过命名 PEM 引用的路径）也会通过这些手表实时轮换。仅内联对保持静态。适用于普通入站TLS和QUIC，包括Hysteria2、TUIC和XHTTP。出站客户端证书、信任根和本地 ShadowTLS 握手证书会在引用的文件发生更改（包括命名的 PEM 引用）时触发完整的 CLI 配置重新加载。如果一个文件同时扮演这两个角色，则仍然需要完全重新加载。 REALITY 的握手行为不变。

新的握手使用当前证书，而不替换 TCP 监听器或 QUIC 端点。 TLS 会话状态的范围仅限于证书生成和监听器的安全策略：会话在一代内恢复，但不会跨轮换或过期。现有的 TCP 和 QUIC 会话不会停用。

### 内置ACME

ACME 使用 `instant-acme` 和显式配置的域。从 CA 的暂存目录开始。 `--dry-run`期间不颁发证书。

```yaml
- certificate_source: public
  type: acme
  domains: [proxy.example.com]
  directory_url: https://acme-staging-v02.api.letsencrypt.org/directory
  state_dir: /var/lib/shoes/acme/public
  contacts: [mailto:operator@example.com]
  # Read the CA's terms, then set this to its exact meta.termsOfService URL.
  terms_of_service: https://example.invalid/replace-with-accepted-ca-terms-url
  challenge:
    type: http01
    listen: ["0.0.0.0:8080"]
```

如文件源示例中所示，从 TLS 或 QUIC 引用 `public`。域必须是唯一的小写 ASCII DNS 名称（使用 punycode 作为国际化名称）。每个使用 ACME 源的命名 TLS 目标都必须被其域覆盖。没有根据传入的SNI进行发行。

`terms_of_service` 明确接受该确切 URL，而不是全面接受未来条款。 shoes 在帐户操作之前检查目录的 `meta.termsOfService` 并拒绝更改的 URL。查看新条款并更新配置以接受它们。如果私有 CA 未发布任何条款，则省略此字段；随后公布的条款 URL 仍需要明确接受。该版本不支持需要外部账号绑定的账号。

HTTP-01要求：

- CA 必须到达每个域的公共 TCP 端口 80，转发到显式 `listen` 地址之一。 shoes从不隐式绑定端口80。
- 质询监听器独立于代理监听器，因此仅 UDP QUIC 部署可以使用 HTTP-01。反向代理/CDN 必须转发准确的 `/.well-known/acme-challenge/` 路径和原始主机标头。
- 侦听地址不得与另一个 HTTP-01 源或 TCP 代理监听器重叠。共享挑战地址时使用单个多域源。空运行检查文字地址和端口范围；同一端口上的主机名绑定 TCP 监听器被保守地视为冲突。
- 仅回答确切的、未决的、未过期的 GET 挑战。未知令牌返回 404。标头限制为 8 KiB / 32 个字段，每个地址最多有 64 个并发连接，请求生命周期为 10 秒。

对于 TLS-ALPN-01，将 `challenge` 映射替换为：

```yaml
  challenge: {type: tls_alpn01}
```

CA 必须到达公共 TCP 端口 443，转发到覆盖每个配置域的现有最外层 shoes TLS 监听器。这不是 QUIC、ShadowTLS 或 REALITY 验证。中间的TLS终结器必须让握手通过，包括SNI和ALPN。 shoes 仅为待配置的 SNI 应答唯一提供的协议 `acme-tls/1`。短暂的质询响应使用 RFC 8737 关键 `acmeIdentifier` 扩展，并且永远不会进入代理处理程序或替换普通证书。普通 ALPN、客户端身份验证、回退路由和 QUIC 策略保持不变。

首次启动时，代理和质询监听器在发布开始之前绑定。没有证书的源的正常握手会失败，直到颁发成功为止； `Servers ready` 表示监听器已绑定，而不是 ACME 已完成。有效的缓存证书允许在 CA 中断期间立即启动。

shoes 将注册前的帐户密钥、帐户凭据、进行中的订单和 CSR 密钥以及证书/密钥对保留在一个自动替换的同步状态文件中。请勿编辑它或在来源之间共享它。在 Unix 上，状态目录必须由模式 0700 的运行用户拥有，文件使用 0600。其他平台使用其继承的文件系统访问控制；将目录放置在私有应用程序存储中。独占操作系统文件锁可防止多个进程或嵌入式生命周期拥有同一目录。安全地备份整个目录。更改 CA 或域列表需要不同的状态目录；舞台和制作绝不能共用一个。

续订通常在证书剩余寿命的三分之一时开始。 ARI 在空闲时进行检查，并且当 CA 和证书支持时可以请求提前续订。其Retry-After仅适用于ARI；可选检查（包括帐户设置）不能延迟到期续订。源工作人员单独安排请求和持久的最后期限。挂单使用五秒的轮询间隔，除非 CA 请求更长的等待时间。瞬时故障可保留有效材料，并使用从 60 秒到 6 小时的抖动指数退避，以支持更长的 CA Retry-After 值。等待超过 100 年或超出平台时钟范围后重试将被拒绝。每个工作步骤的时间限制为 10 分钟。待定订单和正在处理的订单将受到轮询，直到 CA 完成、使它们失效或删除它们。已完成的对在生效之前会被持久化。存储错误不会发布未持久化的替换。订单重试截止日期，包括成功完成和恢复的订单，在重启后仍有效；启动会记录继承的延迟而不是绕过它。故障退避在安装或正常空闲后重置，而不是在延迟唤醒或成功的中间顺序步骤后重置。它的指数被保存在内存中；选定的截止日期在重新启动后仍然有效。 ARI 重试截止日期在重启后也有效，包括失败的 ARI 响应。丢失或无效的订单将被丢弃，以便稍后尝试创建新订单。使用默认的仅错误日志记录可以看到证书失败和继承的重试延迟；成功的发行和轮换使用信息级别。在延迟轮询期间，挂起的质询响应仍然可用，直到其 10 分钟租约到期、订单离开挂起状态或源停止为止。

CA 流量直接通过操作系统解析器和 shoes 受保护的 TCP 套接字帮助程序，而不是通过代理规则或正在颁发的证书。 HTTPS 验证 CA 主机名和公共根。可选的 `ca_cert: /path/to/test-ca.crt` 替换私有 CA 的这些根。请求的总超时时间为 30 秒，响应标头限制为 32 KiB，响应正文限制为 1 MiB；不遵循重定向。仅在用于本地测试的数字环回地址上接受普通 HTTP 目录/端点。切勿禁用公共 CA 的验证。

配置重新加载重用未更改的源及其工作人员、帐户和待处理的挑战。当经过验证的重新加载提交时，更改的源会移交存储并挑战监听器。在新的代理监听器绑定之前释放已退休的质询端口；失败的准备不会改变实时源。当现有代理地址移动到 HTTP-01 时，其质询绑定将被推迟，直到旧代理停止为止。还支持缩小同一 IP 系列内的代理通配符。其他质询地址在准备过程中仍处于绑定状态：扩大绑定、更改 IP 系列或替换质询通配符绑定可能需要重新启动或两次单独的重新加载以避免冲突。已删除的源将被取消。 CLI 和移动/FFI 使用相同的管理器，没有进程全局证书注册表。移动部署仍然需要外部可访问的质询端口和持久的应用程序存储。

`--dry-run` 验证配置、引用、域覆盖、质询兼容性、证书材料和声明的地址冲突，而无需联系 CA、绑定端口或创建 ACME 状态。未发布的 ACME 源是有效配置，而不是自签名占位符。检查现有的可读状态是否存在 CA/域身份不匹配的情况，而无需锁定或修改它；该检查不需要以服务用户身份运行。在运行时准备期间检查实际操作系统端口冲突、存储所有权和权限。

没有内置的 DNS-01、通配符 ACME 发行、DNS 供应商 API、shell hook、Tailscale 提供商或 Cloudflare Origin CA 提供商。对于通配符证书或 DNS-01，请运行外部客户端（例如 acme.sh、lego 或 Certbot）并使用文件源。仍然支持手动提供的通配符证书。

示例：[文件轮换和重用](/zh-cn/examples/certificates_files/) 和 [具有共享 TCP/QUIC 使用者的 ACME](/zh-cn/examples/certificates_acme/)。
