package io.legado.app.ui.book.explore

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import androidx.core.view.children
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.google.android.material.tabs.TabLayout
import fi.iki.elonen.NanoHTTPD
import io.legado.app.R
import io.legado.app.constant.PreferKey
import io.legado.app.data.appDb
import io.legado.app.data.entities.BookSource
import io.legado.app.data.entities.ReadRecord
import io.legado.app.data.entities.SearchBook
import io.legado.app.data.entities.rule.ExploreRule
import io.legado.app.databinding.ActivityBookSearchBinding
import io.legado.app.databinding.ActivityExploreShowBinding
import io.legado.app.help.config.AppConfig
import io.legado.app.help.storage.Restore
import io.legado.app.help.storage.writePreferenceSnapshot
import io.legado.app.ui.book.search.SearchActivity
import io.legado.app.ui.book.search.SearchAdapter
import io.legado.app.utils.defaultSharedPreferences
import io.legado.app.utils.dpToPx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

@RunWith(AndroidJUnit4::class)
class ExploreCategoriesTest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private val context = instrumentation.targetContext.applicationContext
    private val preferences = context.defaultSharedPreferences
    private val originalCategories = preferences.all[PreferKey.showExploreCategories]
    private val originalCronet = preferences.all[PreferKey.cronet]
    private val originalReadRecord = preferences.all[PreferKey.showSearchReadRecord]
    private val slowStarted = CountDownLatch(1)
    private val releaseSlow = CountDownLatch(1)
    private val slowFinished = CountDownLatch(1)
    private val initialRequestCount = AtomicInteger()
    private val releaseInitial = CountDownLatch(1)
    @Volatile
    private var blockInitial = false
    private val server = object : NanoHTTPD("127.0.0.1", 0) {
        override fun serve(session: IHTTPSession): Response {
            if (session.uri == "/category/0" && blockInitial) {
                initialRequestCount.incrementAndGet()
                releaseInitial.await(20, TimeUnit.SECONDS)
            }
            if (session.uri == "/category/1") {
                slowStarted.countDown()
                releaseSlow.await(20, TimeUnit.SECONDS)
            }
            val category = session.uri.substringAfterLast('/')
            val page = session.parameters["page"]?.firstOrNull() ?: "1"
            val ids = when {
                category == "2" && page == "3" -> (50..69).toList()
                category == "2" && page == "2" -> listOf(51) + (30..48)
                else -> (1..20).toList()
            }
            val html = ids.joinToString("") {
                val bookPath = if (category == "2") "/book/$category/$it" else "/book/$category/$page/$it"
                "<a href='$bookPath'>Category $category page $page book $it</a>"
            }
            if (category == "1") slowFinished.countDown()
            return newFixedLengthResponse(Response.Status.OK, "text/html", html)
        }
    }
    private lateinit var source: BookSource
    private var scenario: ActivityScenario<ExploreShowActivity>? = null

    private fun categoryUrl(index: Int) =
        "http://127.0.0.1:${server.listeningPort}/category/$index?page={{page}}"

    @Before
    fun setUp() {
        preferences.edit().remove(PreferKey.showExploreCategories)
            .putBoolean(PreferKey.cronet, false).commit()
        server.start()
        source = BookSource(
            bookSourceUrl = "http://127.0.0.1:${server.listeningPort}/${UUID.randomUUID()}",
            bookSourceName = "Explore categories fixture",
            exploreUrl = (0 until 22).joinToString("&&") { "Category $it::${categoryUrl(it)}" },
            ruleExplore = ExploreRule(bookList = "tag.a", name = "text", bookUrl = "href"),
        )
        appDb.bookSourceDao.insert(source)
        launch()
        awaitActivity { it.model.getLoadedBooks().size == 20 }
    }

    @After
    fun tearDown() {
        releaseSlow.countDown()
        releaseInitial.countDown()
        blockInitial = false
        scenario?.close()
        server.stop()
        if (::source.isInitialized) {
            appDb.bookSourceDao.delete(source.bookSourceUrl)
            appDb.openHelper.writableDatabase.execSQL(
                "DELETE FROM searchBooks WHERE origin = ?", arrayOf(source.bookSourceUrl),
            )
        }
        preferences.edit().apply {
            if (originalCategories == null) remove(PreferKey.showExploreCategories)
            else putBoolean(PreferKey.showExploreCategories, originalCategories as Boolean)
            if (originalCronet == null) remove(PreferKey.cronet)
            else putBoolean(PreferKey.cronet, originalCronet as Boolean)
            if (originalReadRecord == null) remove(PreferKey.showSearchReadRecord)
            else putBoolean(PreferKey.showSearchReadRecord, originalReadRecord as Boolean)
        }.commit()
    }

    @Test
    fun returningToSearchAndDiscoverRefreshesSharedReadRecordIndicators() {
        lateinit var book: SearchBook
        scenario!!.onActivity { book = it.model.getLoadedBooks().first() }
        val record = ReadRecord(deviceId = UUID.randomUUID().toString(), bookName = book.name)
        AppConfig.showSearchReadRecord = true
        appDb.readRecordDao.insert(record)
        var search: ActivityScenario<SearchActivity>? = null
        fun exploreIndicator(activity: ExploreShowActivity): View? {
            val recycler = activity.ui.recyclerView
            val position = (recycler.adapter as ExploreShowAdapter).getHeaderCount()
            return recycler.findViewHolderForAdapterPosition(position)?.itemView
                ?.findViewById(R.id.iv_read_record)
        }
        try {
            awaitActivity { exploreIndicator(it)?.isVisible == true }
            scenario!!.moveToState(Lifecycle.State.CREATED)
            AppConfig.showSearchReadRecord = false
            scenario!!.moveToState(Lifecycle.State.RESUMED)
            awaitActivity { exploreIndicator(it)?.isVisible == false }
            scenario!!.onActivity {
                assertFalse(it.ui.titleBar.menu.findItem(R.id.menu_show_read_record).isChecked)
            }
            scenario!!.moveToState(Lifecycle.State.CREATED)
            AppConfig.showSearchReadRecord = true
            scenario!!.moveToState(Lifecycle.State.RESUMED)
            awaitActivity { exploreIndicator(it)?.isVisible == true }
            scenario!!.onActivity {
                assertTrue(it.ui.titleBar.menu.findItem(R.id.menu_show_read_record).isChecked)
            }

            // ActivityScenario starts a new task, so finish discovery before testing search.
            scenario!!.close()
            scenario = null
            AppConfig.showSearchReadRecord = false

            search = ActivityScenario.launch(Intent(context, SearchActivity::class.java))
            search!!.onActivity {
                it.ui.llInputHelp.isVisible = false
                (it.ui.recyclerView.adapter as SearchAdapter).setItems(listOf(book))
            }
            fun awaitSearchIndicator(visible: Boolean) {
                val deadline = SystemClock.uptimeMillis() + 15000
                do {
                    var matches = false
                    search!!.onActivity {
                        val indicator = it.ui.recyclerView.findViewHolderForAdapterPosition(0)
                            ?.itemView?.findViewById<View>(R.id.iv_read_record)
                        matches = indicator?.isVisible == visible &&
                            it.ui.titleBar.menu.findItem(R.id.menu_show_read_record).isChecked == visible
                    }
                    if (matches) return
                    SystemClock.sleep(50)
                } while (SystemClock.uptimeMillis() < deadline)
                throw AssertionError("Search indicator and menu did not become $visible")
            }
            awaitSearchIndicator(false)
            search!!.moveToState(Lifecycle.State.CREATED)
            AppConfig.showSearchReadRecord = true
            search!!.moveToState(Lifecycle.State.RESUMED)
            awaitSearchIndicator(true)
            search!!.moveToState(Lifecycle.State.CREATED)
            AppConfig.showSearchReadRecord = false
            search!!.moveToState(Lifecycle.State.RESUMED)
            awaitSearchIndicator(false)
        } finally {
            search?.close()
            appDb.readRecordDao.delete(record)
        }
    }

    @Test
    fun globalToggleRendersBalancedRowsAndSurvivesReopening() {
        scenario!!.onActivity {
            assertFalse(AppConfig.showExploreCategories)
            assertFalse(it.ui.categoriesContainer.isVisible)
            toggleCategories(it)
        }
        awaitActivity { it.ui.categoriesContainer.childCount == 3 }
        scenario!!.onActivity {
            assertTrue(AppConfig.showExploreCategories)
            assertEquals(listOf(8, 7, 7), rows(it).map { tabs -> tabs.tabCount })
            assertTrue(rows(it).all { tabs -> tabs.tabMode == TabLayout.MODE_SCROLLABLE })
            assertTrue(rows(it).all { tabs -> tabs.minimumHeight <= 40.dpToPx() })
            assertTrue(rows(it).all { tabs ->
                (tabs.getChildAt(0) as ViewGroup).children.all { tab ->
                    tab.paddingLeft == 12.dpToPx() && tab.paddingRight == 12.dpToPx()
                }
            })
            val categoriesLocation = IntArray(2)
            val booksLocation = IntArray(2)
            it.ui.categoriesContainer.getLocationOnScreen(categoriesLocation)
            it.ui.recyclerView.getLocationOnScreen(booksLocation)
            assertTrue(categoriesLocation[1] + it.ui.categoriesContainer.height <= booksLocation[1])
        }
        screenshot("explore-categories")
        scenario!!.close()
        launch()
        awaitActivity { it.ui.categoriesContainer.isVisible }
        scenario!!.onActivity {
            assertTrue(it.ui.titleBar.menu.findItem(R.id.menu_show_explore_categories).isChecked)
            toggleCategories(it)
            assertFalse(it.ui.categoriesContainer.isVisible)
        }
    }

    @Test
    fun backupRestoresToggleAndLegacyBackupResetsIt() {
        scenario!!.close()
        scenario = null
        val directory = File(context.cacheDir, "explore-backup-${UUID.randomUUID()}")
        val oldTitlePreference = preferences.all[PreferKey.showReadTitleChapterNameOnly]
        try {
            writePreferenceSnapshot(context, directory.path, "config") {
                putBoolean(PreferKey.showExploreCategories, true)
            }
            AppConfig.showExploreCategories = false
            runBlocking(Dispatchers.IO) { Restore.restoreLocked(directory.path) }
            assertTrue(AppConfig.showExploreCategories)
            writePreferenceSnapshot(context, directory.path, "config") { }
            runBlocking(Dispatchers.IO) { Restore.restoreLocked(directory.path) }
            assertFalse(AppConfig.showExploreCategories)
        } finally {
            preferences.edit().apply {
                if (oldTitlePreference == null) remove(PreferKey.showReadTitleChapterNameOnly)
                else putBoolean(PreferKey.showReadTitleChapterNameOnly, oldTitlePreference as Boolean)
            }.commit()
            directory.deleteRecursively()
        }
    }

    @Test
    fun prependingOverlappingPageRetainsVisibleBook() {
        scenario!!.onActivity {
            it.model.switchCategory(ExploreCategory("Category 2", categoryUrl(2)))
            it.model.skipPage(3)
            it.model.explore()
        }
        awaitActivity { it.model.pageLiveData.value == 3 && it.model.getLoadedBooks().size == 20 }
        scenario!!.onActivity {
            val manager = it.ui.recyclerView.layoutManager as LinearLayoutManager
            manager.scrollToPositionWithOffset(1, 0)
        }
        instrumentation.waitForIdleSync()
        var anchor: String? = null
        var top = 0
        scenario!!.onActivity {
            val manager = it.ui.recyclerView.layoutManager as LinearLayoutManager
            val position = manager.findFirstVisibleItemPosition()
            val adapter = it.ui.recyclerView.adapter as ExploreShowAdapter
            anchor = adapter.getItemByLayoutPosition(position)?.bookUrl
            assertTrue(anchor!!.endsWith("/50"))
            top = manager.findViewByPosition(position)!!.top
            it.model.explore(2)
        }
        awaitActivity { it.model.pageLiveData.value == 2 && it.model.getLoadedBooks().size == 39 }
        instrumentation.waitForIdleSync()
        scenario!!.onActivity {
            val manager = it.ui.recyclerView.layoutManager as LinearLayoutManager
            val position = manager.findFirstVisibleItemPosition()
            val adapter = it.ui.recyclerView.adapter as ExploreShowAdapter
            assertEquals(anchor, adapter.getItemByLayoutPosition(position)?.bookUrl)
            assertEquals(top, manager.findViewByPosition(position)!!.top)
        }
    }


    @Test
    fun categorySwitchRejectsLateResponseAndRetainsPageAfterRecreation() {
        scenario!!.onActivity {
            toggleCategories(it)
        }
        awaitActivity { it.ui.categoriesContainer.childCount == 3 }
        scenario!!.onActivity { rows(it)[0].getTabAt(1)!!.select() }
        assertTrue("Slow category request started", slowStarted.await(15, TimeUnit.SECONDS))
        scenario!!.onActivity { rows(it)[1].getTabAt(0)!!.select() }
        awaitActivity {
            rows(it).map { tabs -> tabs.selectedTabPosition } == listOf(-1, 0, -1) &&
                rows(it).flatMap { tabs -> (0 until tabs.tabCount).mapNotNull { tabs.getTabAt(it)?.view } }
                    .count { view -> view.isSelected || view.isActivated } == 1 &&
                rows(it).map(::indicatorVisible) == listOf(false, true, false)
        }
        awaitActivity { it.model.getLoadedBooks().firstOrNull()?.name?.startsWith("Category 8") == true }
        releaseSlow.countDown()
        assertTrue(slowFinished.await(15, TimeUnit.SECONDS))
        scenario!!.onActivity { it.model.explore() }
        awaitActivity { it.model.pageLiveData.value == 2 }
        scenario!!.onActivity {
            assertEquals(40, it.model.getLoadedBooks().size)
            assertTrue(it.model.getLoadedBooks().all { book -> book.name.startsWith("Category 8") })
        }
        scenario!!.moveToState(Lifecycle.State.CREATED).moveToState(Lifecycle.State.RESUMED)
        scenario!!.recreate()
        awaitActivity { it.ui.categoriesContainer.childCount == 3 }
        scenario!!.onActivity {
            assertEquals("Category 8", it.ui.titleBar.title.toString())
            assertEquals(2, it.model.pageLiveData.value)
            assertEquals(40, it.model.getLoadedBooks().size)
            assertEquals(40, (it.ui.recyclerView.adapter as ExploreShowAdapter).getActualItemCount())
            assertEquals(listOf(-1, 0, -1), rows(it).map { tabs -> tabs.selectedTabPosition })
            assertEquals(1, rows(it).flatMap { tabs ->
                (0 until tabs.tabCount).mapNotNull { tabs.getTabAt(it)?.view }
            }.count { view -> view.isSelected || view.isActivated })
            assertEquals(listOf(false, true, false), rows(it).map(::indicatorVisible))
        }
        screenshot("explore-category-restored")
    }

    @Test
    fun categorySwitchKeepsOnlyTheLastRowSelected() {
        scenario!!.onActivity { toggleCategories(it) }
        awaitActivity { it.ui.categoriesContainer.childCount == 3 }
        fun awaitSelectedRow(row: Int) = awaitActivity {
            rows(it).map { tabs -> tabs.selectedTabPosition } ==
                List(3) { index -> if (index == row) 0 else -1 } &&
                rows(it).flatMap { tabs -> (0 until tabs.tabCount).mapNotNull { tabs.getTabAt(it)?.view } }
                    .count { view -> view.isSelected || view.isActivated } == 1 &&
                rows(it).map(::indicatorVisible) == List(3) { index -> index == row }
        }
        awaitSelectedRow(0)
        for (row in listOf(1, 2, 0)) {
            scenario!!.onActivity { rows(it)[row].getTabAt(0)!!.view.performClick() }
            awaitSelectedRow(row)
        }
        scenario!!.onActivity {
            rows(it)[1].getTabAt(0)!!.view.performClick()
            rows(it)[2].getTabAt(0)!!.view.performClick()
        }
        awaitSelectedRow(2)
        screenshot("explore-category-single-indicator")
    }

    @Test
    fun categoriesRenderBeforeInitialExploreCompletes() {
        scenario!!.close()
        scenario = null
        AppConfig.showExploreCategories = true
        blockInitial = true
        launch()
        assertTrue("Initial explore request started", awaitCondition {
            initialRequestCount.get() > 0
        })
        awaitActivity { it.ui.categoriesContainer.isVisible }
        releaseInitial.countDown()
        awaitActivity { it.model.getLoadedBooks().size == 20 }
    }

    @Test
    fun nonDiscoveryEntryHidesCategoryControls() {
        scenario!!.close()
        scenario = null
        AppConfig.showExploreCategories = true
        launch(discovery = false)
        awaitActivity { it.model.getLoadedBooks().size == 20 }
        scenario!!.onActivity {
            assertFalse(it.ui.categoriesContainer.isVisible)
            assertTrue(it.ui.titleBar.menu.findItem(R.id.menu_show_explore_categories) == null)
        }
    }

    private fun launch(discovery: Boolean = true) {
        scenario = ActivityScenario.launch(Intent(context, ExploreShowActivity::class.java).apply {
            putExtra("sourceUrl", source.bookSourceUrl)
            putExtra("exploreName", "Category 0")
            putExtra("exploreUrl", categoryUrl(0))
            putExtra("showExploreCategories", discovery)
        })
    }

    private fun rows(activity: ExploreShowActivity) =
        activity.ui.categoriesContainer.children.map { it as TabLayout }.toList()

    private fun indicatorVisible(tabs: TabLayout): Boolean {
        val strip = tabs.getChildAt(0)
        if (strip.width == 0 || strip.height == 0) return false
        val bitmap = Bitmap.createBitmap(strip.width, strip.height, Bitmap.Config.ARGB_8888)
        try {
            val canvas = Canvas(bitmap)
            strip.draw(canvas) // Let TabLayout resolve the indicator's drawing bounds.
            bitmap.eraseColor(Color.TRANSPARENT)
            tabs.getTabSelectedIndicator().draw(canvas)
            val pixels = IntArray(bitmap.width * bitmap.height)
            bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
            return pixels.any { Color.alpha(it) != 0 }
        } finally {
            bitmap.recycle()
        }
    }

    private fun toggleCategories(activity: ExploreShowActivity) {
        assertTrue("Category menu action is installed", activity.ui.titleBar.menu
            .performIdentifierAction(R.id.menu_show_explore_categories, 0))
    }

    private val ExploreShowActivity.ui: ActivityExploreShowBinding
        get() = ActivityExploreShowBinding.bind(findViewById<View>(R.id.title_bar).parent as View)

    private val SearchActivity.ui: ActivityBookSearchBinding
        get() = ActivityBookSearchBinding.bind(findViewById<View>(R.id.title_bar).parent as View)

    private val ExploreShowActivity.model: ExploreShowViewModel
        get() = ViewModelProvider(this)[ExploreShowViewModel::class.java]

    private fun awaitActivity(condition: (ExploreShowActivity) -> Boolean) {
        val deadline = SystemClock.uptimeMillis() + 15000
        do {
            var satisfied = false
            scenario!!.onActivity { satisfied = condition(it) }
            if (satisfied) return
            SystemClock.sleep(50)
        } while (SystemClock.uptimeMillis() < deadline)
        var state = ""
        scenario!!.onActivity {
            state = "error=${it.model.errorLiveData.value}, books=${it.model.getLoadedBooks().size}, " +
                "page=${it.model.pageLiveData.value}, categories=${it.model.categoriesData.value?.size}, " +
                "rows=${it.ui.categoriesContainer.childCount}, enabled=${AppConfig.showExploreCategories}"
        }
        throw AssertionError("Timed out: $state")
    }

    private fun awaitCondition(condition: () -> Boolean): Boolean {
        val deadline = SystemClock.uptimeMillis() + 15000
        do {
            if (condition()) return true
            SystemClock.sleep(50)
        } while (SystemClock.uptimeMillis() < deadline)
        return false
    }

    private fun screenshot(name: String) {
        instrumentation.waitForIdleSync()
        val bitmap = checkNotNull(instrumentation.uiAutomation.takeScreenshot())
        try {
            File(context.getExternalFilesDir("ui-regression"), "$name.png").outputStream().use {
                assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it))
            }
        } finally {
            bitmap.recycle()
        }
    }
}
