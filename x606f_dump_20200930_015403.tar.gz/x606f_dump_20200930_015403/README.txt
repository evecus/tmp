TB-X606F 采集结果  20200930_015403
info/          各类文本信息 (proc/sysfs/debugfs/dmesg/getprop ...)
dt/            设备树: device-tree.tar(原始二进制) + properties 文本 [+ .dts 若设备有 dtc]
partitions/    boot/dtbo/lk/preloader 等镜像 (电脑上用 unpackbootimg / dtc 解析)
files/         从 /vendor 等复制的固件、init rc、fstab、内核模块、音频配置
_errors.txt    复制过程中的报错 (在 info/ 下)
230M	/data/local/tmp/x606f_dump_20200930_015403
